const express = require('express');
const cors = require('cors');
// The Stealth Arsenal
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
puppeteer.use(StealthPlugin());
const cheerio = require('cheerio');

const app = express();
const PORT = 3000;

// ALLOW ALL CONNECTIONS (Crucial for AI Studio -> Tunnel access)
app.use(cors({ origin: '*' }));
app.use(express.json());

// We removed 'app.use(express.static)' because your Frontend is in the Cloud.

app.post('/api/scan', async (req, res) => {
    const { url } = req.body;
    console.log(`[Target] Incoming scan request from AI Studio for: ${url}`);
    
    let browser;
    try {
        // 1. Launch Visible Browser (Best for avoiding blocks)
        browser = await puppeteer.launch({
            headless: false, 
            args: ['--no-sandbox', '--disable-setuid-sandbox', '--start-maximized']
        });
        
        const page = await browser.newPage();
        
        // 2. Set up the "Wiretap" (Intercepting Cookies in mid-air)
        const interceptedCookies = [];
        page.on('response', response => {
            const headers = response.headers();
            if (headers['set-cookie']) {
                // Clean up the raw header to get just the cookie
                const rawCookies = headers['set-cookie'].split('\n');
                rawCookies.forEach(c => {
                    interceptedCookies.push({
                        url: response.url(),
                        cookie: c.split(';')[0]
                    });
                });
            }
        });

        // 3. Navigate
        console.log('[Status] Visiting page...');
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });

        // 4. The "Human" Pause (Wait for scripts to settle)
        await new Promise(r => setTimeout(r, 5000));

        // 5. Extract Content (Cheerio)
        const content = await page.content();
        const $ = cheerio.load(content);
        
        const meta = {
            title: $('title').text().trim() || 'No Title',
            description: $('meta[name="description"]').attr('content') || 'No Description',
        };

        // 6. Extract Contacts (Simple Regex scan)
        const bodyText = $('body').text();
        const emails = bodyText.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi) || [];
        
        // 7. Extract Local Storage (Hidden Tokens)
        const localStorageData = await page.evaluate(() => JSON.stringify(localStorage));

        // 8. Screenshot
        const screenshotBuffer = await page.screenshot({ encoding: 'base64', fullPage: false });

        console.log(`[Success] Scan complete. Found ${interceptedCookies.length} cookies.`);

        // 9. Send Data back to AI Studio
        res.json({
            status: 'success',
            meta: meta,
            contacts: [...new Set(emails)], // Remove duplicates
            cookies: interceptedCookies,
            localStorage: JSON.parse(localStorageData),
            screenshot: `data:image/png;base64,${screenshotBuffer}`
        });

    } catch (error) {
        console.error(`[Error] ${error.message}`);
        if(browser) await browser.close();
        res.json({ status: 'error', message: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`--------------------------------------------------`);
    console.log(`ENGINE ONLINE: Listening on port ${PORT}`);
    console.log(`Waiting for request from Tunnel...`);
    console.log(`--------------------------------------------------`);
});